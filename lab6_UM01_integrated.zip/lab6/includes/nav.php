<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="../index.php">Peer Tutoring Hub</a>
    <div class="navbar-nav">
      <a class="nav-link" href="requests.php">Requests</a>
      <a class="nav-link" href="request-form.php">Request a Session</a>
      <a class="nav-link" href="register.php">Create Account</a>
    </div>
  </div>
</nav>
